﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsForms
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\admin\Documents\MyEmpDb1.mdf;Integrated Security=True;Connect Timeout=30");
        private void fetchempdata()
        {
            Con.Open();
            string query = "select*from MyEmpDb1 where Empid='" + Empidsearch.Text + "'";
            SqlCommand cmd = new SqlCommand(query, Con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach(DataRow dr in dt.Rows)
            {
                Empidlbl.Text = dr["Empid"].ToString();
                EmpNamelbl.Text = dr["EmpName"].ToString();
                Empaddlbl.Text = dr["Empadd"].ToString();
                empposlbl.Text = dr["EmpPos"].ToString();
                EmpPhonelbl.Text = dr["EmpPhone"].ToString();
                EmpEdulbl.Text = dr["EmpEdu"].ToString();
              EmpGenlbl.Text = dr["Empgen"].ToString();
                EmpDOBlbl.Text = dr["Empdob"].ToString();
                Empidlbl.Visible = true;
                EmpNamelbl.Visible = true;
                Empaddlbl.Visible = true;
                empposlbl.Visible = true;
                EmpPhonelbl.Visible = true;
                EmpEdulbl.Visible = true;
                EmpGenlbl.Visible = true;
                EmpDOBlbl.Visible = true;
            }
            Con.Close();
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            fetchempdata();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(printPreviewDialog1.ShowDialog()==DialogResult.OK)
            {
                printDocument1.Print();
            }
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {


           e.Graphics.DrawString("==========EMPLOYEE DETAILS=========", new Font("Century Gothic", 20, FontStyle.Bold), Brushes.Red, new Point(150));
            e.Graphics.DrawString(DashLabel.Text, new Font("Arial", 12), Brushes.Black, new Point(30, 50));
            e.Graphics.DrawString("Employe ID:     "+Empidlbl.Text+"        \tEmployee Name:     "+EmpNamelbl.Text, new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Black, new Point(30,100));
            e.Graphics.DrawString("Employe Address:    " + Empaddlbl.Text + "\tEmployee Gender:    " + EmpGenlbl.Text, new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Black, new Point(30, 150));
            e.Graphics.DrawString("Employe Position:   " +empposlbl.Text + "\tEmployee DOB:    " + EmpDOBlbl.Text, new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Black, new Point(30, 200));
            e.Graphics.DrawString("Employe Mobile No:  " + EmpPhonelbl.Text+"\tEmployee Eduction:    " + EmpEdulbl.Text, new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Black, new Point(30, 250));
            e.Graphics.DrawString(DashLabel.Text, new Font("Arial", 12), Brushes.Black, new Point(30, 300));
            e.Graphics.DrawString("==========Thank you!!!!=========", new Font("Century Gothic", 20, FontStyle.Bold), Brushes.Red, new Point(180,400));
            
        }

        private void Empidsearch_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
