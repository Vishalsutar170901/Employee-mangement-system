﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsForms
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\admin\Documents\MyEmpDb1.mdf;Integrated Security=True;Connect Timeout=30");
        private void Form6_Load(object sender, EventArgs e)
        {

        }
        private void fetchempdata()
        {
            if (EmpIdTb.Text == "")
            {
                MessageBox.Show("enter Employee Id");
            } else
            {
                Con.Open();
                string query = "select*from MyEmpDb1 where Empid='" + EmpIdTb.Text + "'";
                SqlCommand cmd = new SqlCommand(query, Con);
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    EmpIdTb.Text = dr["Empid"].ToString();
                    EmpNameTb.Text = dr["EmpName"].ToString();

                    EmpPosCB.Text = dr["EmpPos"].ToString();

                }
                Con.Close();

            }

        }


        private void button3_Click(object sender, EventArgs e)
        {
            fetchempdata();
        }
        int Dailybase;
        private int total;

        private void button2_Click(object sender, EventArgs e)
        {
            if (EmpIdTb.Text == "")
            {
                MessageBox.Show("select An Employee");
            }
            else if (WorkTb.Text == "" || Convert.ToInt32(WorkTb.Text) > 80)
            {
                MessageBox.Show("Enter A Valid Number Of Days");
            } else
            {
                if (EmpPosCB.Text == "SOFTWARE DEVELOPER")
                {
                    Dailybase = 1200;
                } else if (EmpPosCB.Text == "DATABASE ADMINISTRATOR")
                {
                    Dailybase =1000;
                } else if (EmpPosCB.Text == "WEB DEVELOPER")
                {
                    Dailybase = 950;
                } else
                {
                    Dailybase = 850;
                }

                total = Dailybase * Convert.ToInt32(WorkTb.Text);

                salaryslip.Text ="Employye id:   " +EmpIdTb.Text + "\n"+"Employye Name:   " + EmpNameTb.Text + "\n" +"Employee Position:   "+ EmpPosCB.Text + "\n"+ "Days Work:   "+ WorkTb.Text + "\n" +"Daily Salary Rs   :"+ Dailybase + "\n" +"Total Amount Rs   :" +total;

        }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.Print();
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("==========SALARY DETALS=========", new Font("Century Gothic", 20, FontStyle.Bold), Brushes.Red, new Point(150));
            e.Graphics.DrawString("Employe ID:  " + EmpIdTb.Text ,new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Black, new Point(30, 100));
            e.Graphics.DrawString("Employe Position:  " + EmpPosCB.Text, new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Black, new Point(30, 150));
            e.Graphics.DrawString("Employe Name:  " + EmpNameTb.Text , new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Black, new Point(30, 200));
            e.Graphics.DrawString("Work Days:  " + WorkTb.Text, new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Black, new Point(30, 250));
            e.Graphics.DrawString("Daily Pay:  " + Dailybase, new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Black, new Point(30, 300));
            e.Graphics.DrawString("Total Salary:  " + total, new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Black, new Point(30, 350));
            e.Graphics.DrawString(DashLabel.Text, new Font("Arial", 12), Brushes.Black, new Point(30, 400));

           e.Graphics.DrawString("==========Thank you!!!!=========", new Font("Century Gothic", 20, FontStyle.Bold), Brushes.Red, new Point(180, 700));


        }

        private void WorkTb_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }


   

